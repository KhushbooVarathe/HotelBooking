var express = require('express')
const app = express()
const {register,login} = require('../controllers/auth')
// const login = require('../controllers/auth')
console.log('auth api')
app.post('/register', register)
app.post('/login', login)
module.exports = app
