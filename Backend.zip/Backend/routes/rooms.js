var express = require('express')
const app = express()

const {getoneRoom,Room,deleteRoom,updateRoom,createRoom}=require('../controllers/rooms')

const { verifyAdmin } = require('../utils/verifyToken')

//get
app.get('/getoneRoom/:id',getoneRoom)
//getall
app.get('/Room',Room)
//create
app.post('/createRoom/:hotelId',verifyAdmin,createRoom)
//update

app.put('/updateRoom/:id',verifyAdmin,updateRoom)
//delete
app.delete('/deleteRoom/:id/:hotelId',verifyAdmin,deleteRoom)

module.exports=app;