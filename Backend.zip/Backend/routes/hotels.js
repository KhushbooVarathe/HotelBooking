var express = require('express')
const app = express()
// const HotelSchema=require('../modals/Hotels')
const {hotels,countByCity,createHotel,updateHotels,deleteHotels,getonehotel}=require('../controllers/hotels')
// const createHotel=require('../controllers/hotels')
// const updateHotels=require('../controllers/hotels')
// const deleteHotels=require('../controllers/hotels')
// const getonehotel=require('../controllers/hotels')
const { verifyAdmin } = require('../utils/verifyToken')
// const { createError } = require('../utils/error')
console.log("auth api")
// var createError=require('../utils/error')
//get
app.get('/getonehotel/:id',getonehotel)

//create
app.post('/createHotels',verifyAdmin,createHotel)
//update

app.put('/updateHotels/:id',verifyAdmin,updateHotels)
//delete
app.delete('/deleteHotels/find/:id',verifyAdmin,deleteHotels)

//getall
app.get('/hotels',hotels)
app.get('/hotels/countByCity',countByCity)
app.get('/hotels/countByType',hotels)


module.exports=app;