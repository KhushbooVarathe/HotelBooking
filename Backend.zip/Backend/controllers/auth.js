const bcrypt = require('bcrypt');
const userSchema = require('../modals/Users');
var jwt = require('jsonwebtoken');
// const secretAccesskey='hewfehfhbgbshfbeheheh22122hhgfkdvbpdmgdnAfhcgdfd'
const register = async (req, res, next) => {
    console.log(req.body);
    try {
        console.log("heloo");
        const { username, email, password } = req.body;

        // Generate a salt with 10 rounds, this will be used to hash the password
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        const newUser = new userSchema({
            username: username,
            email: email,
            password: hashedPassword // Store the hashed password in the database
        });

        console.log(newUser, "newUser");
       const newnewUser= await newUser.save();
       console.log(newnewUser.isAdmin,"newnewUser",typeof(newnewUser))
        res.status(200).send({data:"Registered Successfully",newData:newnewUser.isAdmin});
    } catch (err) {
        next(err);
    }
};
const login = async (req, res, next) => {
    console.log(req.body,"hheehhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh");
    try {
        console.log("hello");
        const { email, password } = req.body;

        // Find the user by email in the database
        const user = await userSchema.findOne({ email });
console.log(user,"user")
        if (!user) {
            return res.send("User not found");
        }

        // Compare the provided password with the stored hashed password
        const isPasswordValid = await bcrypt.compare(password, user.password);
        console.log("isPasswordValid",isPasswordValid)
        if (!isPasswordValid) {
            return res.send("Invalid password");
        }
        const token=jwt.sign({id:user._id, isAdmin:user.isAdmin},process.env.JWT,{
            expiresIn: '7d'
          })
        console.log("token",token)
        // Password is valid, proceed with your authentication logic here
        // For example, you can generate a JWT token and send it back as a response

        res.cookie("access_token",token,{
            httpOnly:true,
        }).status(200).send({data:"Login successful",isAdmin:user.isAdmin,user:user.username,token:token});
    } catch (err) {
        next(err);
    }
};

module.exports ={ register,login};
// module.exports = login;


// const userSchema=require('../modals/Users')
// const register=async(req,res,next)=>{
//     console.log(req.body)
//     try{
//         console.log("heloo")
//         const newUser=new userSchema({
//             username:req.body.username,
//             email:req.body.email,
//             password:req.body.password
//         })
//         console.log(newUser,"newUser")
//         await newUser.save()
//         res.status(200).send("Registered Successfully")
//     }catch(err){
// next(err)
//     }

// }
// module.exports=register;