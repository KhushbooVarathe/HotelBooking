const HotelSchema = require('../modals/Hotels')

const createHotel = async (req, res, next) => {
  console.log('req.body', req.body)
  const newHotel = await new HotelSchema(req.body)
  console.log('newHotellllllll', newHotel)
  try {
    const saveHotel = await newHotel.save()
    console.log(saveHotel, 'saveHotel')
    res.status(200).send(saveHotel)
  } catch (err) {
    console.log('er', err)
    // res.status(500).json(err)
    next(err)
  }
}

const updateHotels = async (req, res, next) => {
  console.log('req.body', req.body)

  try {
    const updatenewHotel = await HotelSchema.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    )
    console.log('updatenewHotel', updatenewHotel)
    res.status(200).send(updatenewHotel)
  } catch (err) {
    // console.log("er",err)
    // res.status(500).json(err)
    next(err)
  }
}

const deleteHotels = async (req, res, next) => {
  console.log('req.body', req.body)

  try {
    const deletenewHotel = await HotelSchema.findByIdAndDelete(req.params.id)
    console.log('deletenewHotel', deletenewHotel)
    res.status(200).send('hotel has been deleted')
  } catch (err) {
    // console.log("er",err)
    // res.status(500).json(err)
    next(err)
  }
}

const hotels = async (req, res, next) => {
  console.log('I am hotel routesooooooooo', req.body, 'hehehheeh')

  try {
    const AllHotels = await HotelSchema.find()
    res.status(200).send(AllHotels)
  } catch (err) {
    next(err)
    // console.log("er",err)
    // res.status(500).json(err)
  }
}

const getonehotel=async(req,res,next)=>{
    console.log("I am hotel routes",req.body,"hehehheeh")

    try{
        const AllHotels=await HotelSchema.findById(req.params.id)
res.status(200).send(AllHotels)
    }catch(err){
        next(err)
        // console.log("er",err)
// res.status(500).json(err)
    }
}

const countByCity = async (req, res, next) => {
  console.log('I am hotel routesooeeeeeeeeeeeeeeeeooooooo', req.query.cities, 'hehehheeh')
const cities=req.query.cities.split(',')
  try {
    const list=await Promise.all(cities.map(city=>{
      return HotelSchema.countDocuments({city:city})
    }))
    
    res.status(200).send(list)
  } catch (err) {
    next(err)
    // console.log("er",err)
    // res.status(500).json(err)
  }
}

module.exports = {hotels,countByCity,getonehotel, createHotel, deleteHotels, updateHotels}
