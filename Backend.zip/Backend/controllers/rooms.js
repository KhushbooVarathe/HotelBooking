const RoomSchema = require('../modals/Room')
const HotelSchema=require('../modals/Hotels')
const createError = require('../utils/error')
const createRoom = async (req, res, next) => {
  const hotelId = req.params.hotelId
  console.log(hotelId,"hotelId")
  const newRoom = new RoomSchema(req.body)
  console.log(newRoom,"newRoom")
  try {
    const savedRoom = await newRoom.save()
    console.log(savedRoom,"savedRoom")
    try {
      await HotelSchema.findByIdAndUpdate(hotelId, {
        $push: { rooms: savedRoom._id }
      })
    } catch (error) {
      next(error)
    }
    res.status(200).json(savedRoom)
  } catch (error) {
    next(error)
  }
}
const updateRoom = async (req, res, next) => {
  console.log('req.body', req.body)

  try {
    const updatenewRoom = await RoomSchema.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    )
    console.log('updatenewRoom', updatenewRoom)
    res.status(200).send(updatenewRoom)
  } catch (err) {
    // console.log("er",err)
    // res.status(500).json(err)
    next(err)
  }
}

const deleteRoom = async (req, res, next) => {
  console.log('req.body', req)
  const hoteldeleteId = req.params.hotelId
  console.log(hoteldeleteId,"hoteldeleteId",req.params.id)
  try {
    const deletenewRoom = await RoomSchema.findByIdAndDelete(req.params.id)
    console.log('deletenewRoom', deletenewRoom)

    try {
      await HotelSchema.findByIdAndUpdate(hoteldeleteId, {
        $pull: { rooms: req.params.id },
      })
    } catch (error) {
      next(error)
    }




    res.status(200).send('room has been deleted')
  } catch (err) {
    // console.log("er",err)
    // res.status(500).json(err)
    next(err)
  }
}

const Room = async (req, res, next) => {
  console.log('I am room routes', req.body, 'hehehheeh')

  try {
    const Rooms = await RoomSchema.find()
    res.status(200).send(Rooms)
  } catch (err) {
    next(err)
    // console.log("er",err)
    // res.status(500).json(err)
  }
}

const getoneRoom = async (req, res, next) => {
  console.log('I am roomone routes', req.body, 'hehehheeh')

  try {
    const AllRoom = await RoomSchema.findById(req.params.id)
    res.status(200).send(AllRooms)
  } catch (err) {
    next(err)
    // console.log("er",err)
    // res.status(500).json(err)
  }
}

module.exports = { Room,getoneRoom, createRoom, deleteRoom, updateRoom }
