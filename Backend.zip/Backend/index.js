var express = require('express')
const app = express()
require('dotenv').config();
const auth=require('./routes/auth')
const hotels=require('./routes/hotels')
const rooms=require('./routes/rooms')
const users=require('./routes/users')
var cors = require('cors')
app.use(express.json())
app.use(cors())

// const HotelSchema=require('./modals/Hotels')
var cookieParser = require('cookie-parser')
console.log("hello world")
require('./modals/config')
app.use(cookieParser())
app.use('/api',auth)
app.use('/api',hotels)

app.use('/api',rooms)
app.use('/api',users)

app.use((err,req,res,next)=>{
    console.log("i am middleware")
    const errorStatus=err.status || 500
    const errMessage=err.message||"something went wrong"
   return res.status(errorStatus).json({success:false,
status:errorStatus,
message:errMessage,
stack:err.stack
})

})
app.listen(7000,()=>{
    console.log("runnig at port 7000")
})